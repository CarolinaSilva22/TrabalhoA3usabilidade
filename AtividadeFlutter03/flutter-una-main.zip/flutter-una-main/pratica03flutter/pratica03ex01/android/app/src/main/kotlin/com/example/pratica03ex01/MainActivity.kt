package com.example.pratica03ex01

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
