package com.example.pratica03ex03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
